# Update the password reset html templates

1. password_reset_form.html
2. password_reset_done.html
3. password_reset_confirm.html
4. password_reset_complete.html
