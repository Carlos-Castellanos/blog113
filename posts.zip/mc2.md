# Implement password change

1. Create a template for the password change view that allows us to render a form
1.1. The template must match the look and feel of our site.

2. Create a template for the password change done view that allows us to display a confirmation message, letting us know our password change was successful.
2.1. The template must match the look and feel of our site.


Password change
Please enter your old password, for security’s sake, and then enter your new password twice so we can verify you typed it in correctly.

password_change_form.html
registration/password_change_done.html
